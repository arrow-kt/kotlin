package net.consumer

import com.data.Repository
import com.domain.Group
import com.domain.User
import com.validation.Validator

fun <A> validate(a: A, with validator: Validator<A>): Boolean = a.isValid()

fun <A> retrieveIfValid(id: Int, with repository: Repository<A>, with validator: Validator<A>): A? {
  val x = loadById(id)
  if (x == null) return null
  return if (validate(x)) x else null
}

fun program(): String {
  val user = retrieveIfValid<User>(25)
  if (user != User(25, "Bob")) {
    return "fail 1"
  }

  val group = retrieveIfValid<Group>(1)
  return if (group == Group(listOf(User(25, "Bob")))) {
    "OK"
  } else {
    "fail 2"
  }
}

fun main(args: Array<String>) {
  /**
   * Resolution order for extensions is (in this strict order):
   *
   * - 1) Scope of the caller function.
   * - 2) Companion object for the type (User).
   * - 3) Companion object for the contract interface we're looking for (Repository, Validator).
   * - 4) Subpackages of the type to resolve (User).
   * - 5) Subpackages of the contract interface (Repository, Validator).
   *
   * This program has the following requirements to run (constraints):
   * - An extension for Repository<User>, provided in com.data.instances.UserRepository (subpackages of the contract interface, Repository (5)).
   * - An extension for Repository<Group>, provided in com.data.instances.GroupRepository (subpackages of the contract interface, Repository (5)).
   * - An extension for Validator<User>, provided in com.domain.User Companion (companion object for the type (2)).
   * - An extension for Validator<Group>, provided in com.validation.Validator Companion (companion object for the contract interface (3)).
   *
   * All of them are fulfilled, so the program completes successfully.
   */
  println(program()) // successful!

  /**
   * Now, try to remove any of the provided extensions from any of the required places, you'll see compile time detailed errors about extensions
   * not able to resolve. You'll get errors inlined (underline + IDE inspections) and when you hit compile button / run any compile commands.
   */
}
