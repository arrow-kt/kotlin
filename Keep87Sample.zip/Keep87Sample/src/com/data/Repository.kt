package com.data

interface Repository<A> {
  fun loadAll(): List<A>
  fun loadById(id: Int): A?
}
