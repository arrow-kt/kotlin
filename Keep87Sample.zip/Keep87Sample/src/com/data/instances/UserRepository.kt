package com.data.instances

import com.data.Repository
import com.domain.User

extension object UserRepository: Repository<User> {
  override fun loadAll(): List<User> {
    return listOf(User(25, "Bob"))
  }

  override fun loadById(id: Int): User? {
    return if (id == 25) {
      User(25, "Bob")
    } else {
      null
    }
  }
}
