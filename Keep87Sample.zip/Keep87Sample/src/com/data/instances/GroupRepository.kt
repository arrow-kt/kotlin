package com.data.instances

import com.data.Repository
import com.domain.Group
import com.domain.User

extension class GroupRepository(with val userRepository: Repository<User>) : Repository<Group> {
  override fun loadAll(): List<Group> {
    return listOf(Group(userRepository.loadAll()))
  }

  override fun loadById(id: Int): Group? {
    return Group(userRepository.loadAll())
  }
}
