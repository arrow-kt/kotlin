package com.validation

import com.domain.Group
import com.domain.User

interface Validator<A> {
  fun A.isValid(): Boolean

  companion object {
    extension class GroupValidator<A>(with val userValidator: Validator<User>) : Validator<Group> {
      override fun Group.isValid(): Boolean {
        for (x in users) {
          if (!x.isValid()) return false
        }
        return true
      }
    }
  }
}
