package com.domain

import com.validation.Validator

data class User(val id: Int, val name: String) {
  companion object {
    extension class UserValidator(): Validator<User> {
      override fun User.isValid(): Boolean {
        return id > 0 && name.length > 0
      }
    }
  }
}

data class Group(val users: List<User>)
